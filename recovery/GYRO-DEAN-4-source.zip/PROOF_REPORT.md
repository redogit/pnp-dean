# Extended Proof Report

This extension added theorem files 06–21 and integrated them into the existing exact GYRO-DEAN-4 architecture.

## Newly closed claims

- Exactness and termination of the reference branch-and-reduce solver under the carrier contract.
- Safety of compatibility q-core deletion and exclusion-isolated forced inclusion.
- 4-capped include/exclude recurrence and component/join factorization.
- Independent Set / Vertex Cover duality, pressure forcing, and elementary O(k^2) residual kernel.
- Connected non-bipartite regular repair plateau for pressure, LP persistency, crowns, and complement decomposition.
- Exponential exact context frontier and exponential disjointness-matrix rank on a matching cut.
- Soundness of gyroscopic closure; frontier-mass and polynomial-event progress as sufficient conditional polynomial-time theorems.
- Maximal linear PCA characterization of all exact linear invariants, plus the empty-graph counterexample to PCA universality.
- Sound certified Macaulay linearization, affine hypercube mass bound, and exact cardinality ladder.
- Lifted MPCA curvature sandwich and final stabilization theorem.
- Semantic Jacobian / block-curvature theorems.
- Graph-Hilbert bridge `h_k <= i_k(G)`.
- Fractional-dual extreme-support decomposition, odd-cycle defect bound, tight-frame factorization, and near-tight deficits.
- Multi-frame inconsistency / low-nullity affine termination certificates.
- Submodularity of candidate-action rank gain and the greedy rank-cover bound.

## Claims explicitly falsified

See `proofs/21_CLAIM_FALSIFICATION_LEDGER.md` for counterexamples to universal local-degree repair, universal polynomial cut frontiers, universal ordinary-rank compression, universal original-variable PCA collapse, unary/pairwise progress, and static lift-to-completion.

## Executable evidence

- All CMake tests pass.
- Exhaustive comparison with brute force passed every labeled graph through five vertices and every positive target q: **5,405 graph/target cases**.
- Petersen q=4: reference solver returns four valid cohorts.
- G20 q=8: reference solver returns four valid cohorts.
- G20 q=9: reference solver returns no cohort, matching the proved/calibrated `alpha(G20)=8` status.

## Boundary

These results do not prove the universal gyroscopic-dissipation conjectures and do not prove `P=NP`. They strengthen and narrow the research program while preserving the exact branch fallback.

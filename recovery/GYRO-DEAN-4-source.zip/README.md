# GYRO-DEAN-4

Exact gyroscopic solver architecture for the generalized DEAN selection problem:

- choose exactly `q` students from `n` candidates;
- never select an excluded pair;
- respect dorm capacity;
- return four distinct valid cohorts;
- rotate residual states through graph, vertex-cover/LP, dual-frame, SAT, SQL/factor, and certified Macaulay/MPCA carriers;
- preserve correctness with an exact branch-and-reduce fallback.

The software architecture is **exact**, but the universal claim that the gyroscopic reductions make every instance polynomial-time is **not proved**. `P` versus `NP` remains open. The branch fallback is what guarantees correctness.

## Quick start

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
./build/gyro_dean --students examples/students.csv --exclusions examples/exclusions.csv --q 4 --capacity 4
```

## Project map

- `include/gyro/`, `src/` — compilable C++ reference core.
- `src/carriers/` — carrier hooks; advanced carriers are explicit extension points.
- `sql/` — relational carrier / verification queries.
- `pseudocode/` — full algorithm procedures.
- `docs/` — architecture, invariant, gravity, implementation notes.
- `proofs/` — direct theorem/proof ledger from the design thread.
- `tests/` — executable exact-solver tests.
- `CLAIMS.md` — theorem/counterclaim index and proof-status map.
- `evidence/` — finite calibration objects and explicitly non-universal evidence.
- `docs/PROOF_RESEARCH_PROTOCOL.md` — claim → proof/counterexample → repair workflow.

## Governing invariant

Every semantic rotation must preserve the decision problem. Every destructive reduction must be accompanied by a reconstruction/lifting rule. Numerical PCA/SVD may steer; only exact verified rank/equations may cross the proof boundary.
